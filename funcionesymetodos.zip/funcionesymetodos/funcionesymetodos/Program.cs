﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace funcionesymetodos
{
    internal class Program
    {
        static int opcion = 0;  // Variable global
        static float num1 = 0, num2 = 0;
        static void menu()
        {
            int opcion = 0;   // Variable local 

            do
            {

                Console.WriteLine("1-Suma");
                Console.WriteLine("2-resta");
                Console.WriteLine("3-Multiplicacio");
                Console.WriteLine("4-Division");
                Console.WriteLine("5-Salir");
                Console.WriteLine("Digite una opcion");
                int.TryParse(Console.ReadLine(), out opcion);

                if (opcion > 0 && opcion < 5) //Si seleccionamos una operación del menú solicita los números
                {
                    Solicitar();
                }
                                
                switch (opcion)
                {
  
                    case 1:
                        //Solicitar();
                        Console.WriteLine($"Suma: {suma()}");
                        break;
                    case 2:
                        //Solicitar();
                        resta();
                        break;
                    case 3:
                        //Solicitar();
                        Console.WriteLine($"Multiplicacion: {multiplicar(num1, num2)}");
                        break;
                    case 4:
                        //Solicitar();
                        dividir(num1, num2);
                        break;
                    case 5: break;
                    default:
                        break;
                }

            } while (opcion != 5);

        }


        static float suma()
        {
            return num1 + num2;
        }

        static float multiplicar(float v1, float v2)
        {
            return (v1 * v2);

        }
        static void dividir(float v1, float v2)
        {
            Console.WriteLine($"Dividir: {v1 / v2} ");
        }

        static void resta()
        {
            float total = num1 - num2;
            Console.WriteLine($"Resta: {total} ");
        }
        static void Solicitar()
        {
            Console.WriteLine("Digite un numero:");
            num1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite otro numero:");
            num2 = float.Parse(Console.ReadLine());
        }

        static void Main(string[] args)
        {

            opcion = 10;
            menu();



        }
    }
}
